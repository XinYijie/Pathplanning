class Layer:
    def __init__(self,z):
        self.z=z
        self.segments=[]
        self.contours=[]
        self.shellContours = []
        self.ffContours = []
        self.sfContours = []
