        # print(0)
        # for poly in layer.contours:
        #     print(1)
        #     va.drawPolyline(poly).GetProperty().SetColor(0,0,0)
        # for poly in layer.ffContours:
        #     print(2)
        #     va.drawPolyline(poly).GetProperty().SetColor(1,0,0)