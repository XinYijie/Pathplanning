from GenNcCode import *
modelName = 'monkg'
stlModel = StlModel()
stlModel.readStlFile('e:/%s.stl' % modelName)
printParams = PrintParams(stlModel)
nccode = genNcCode(printParams)
print(nccode)
f= open("%s_GCode.gcode" % modelName, "w+")
f.write(nccode)
