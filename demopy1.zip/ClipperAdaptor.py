import math
import Polyline
from GemoBase import Point3D
from pyclipper import *
class ClipperAdaptor:
    def __init__(self,digits=7):
        self.f=math.pow(10,digits)     #数值精度，默认为7位小数
        self.arcTolerance=0.005       #圆弧精度，默认为0.005
    def PolylineToPath(self,poly):    #将polyline转化为PATH
        path=[]
        for pt in poly.points:
            path.append((pt.x*self.f,pt.y*self.f))
        return path
    def PolyToPaths(self,polys):
        paths=[]
        for poly in polys:
            paths.append(self.PolylineToPath(poly))
        return paths
    def PathToPoly(self,path,z=0,closed=True):
        poly=Polyline.Polyline()
        for tp in path:
            poly.addPoint(Point3D(tp[0]/self.f,tp[1]/self.f,z))
        if len(path)>0 and closed:
            poly.addPoint(poly.startPoint())
        return poly
    def PathToPolys(self,paths,z=0,closed=True):
        polys=[]
        for path in paths:
            polys.append(self.PathToPoly(path, z, closed))
        return polys
    def offsetPolygons(self,polys,delta,jt=JT_SQUARE):
        pco=PyclipperOffset()
        pco.ArcTolerance=self.arcTolerance*self.f
        pco.AddPaths(self.PolyToPaths(polys), jt, ET_CLOSEDPOLYGON)
        sln=pco.Execute(delta * self.f)
        return self.PathToPolys(sln,polys[0].point(0).z)
    def offsetPolygon(self,poly,delta,jt=JT_SQUARE):
        pco = PyclipperOffset()
        pco.ArcTolerance = self.arcTolerance * self.f
        path = self.PolylineToPath(poly)
        pco.AddPath(path,jt,ET_CLOSEDPOLYGON)
        sln=pco.Execute(delta*self.f)
        return self.PathToPolys(sln, poly.point(0).z)
