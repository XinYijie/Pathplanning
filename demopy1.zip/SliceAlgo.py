from Layer import *
from LinkSeg_dorder import *
from IntersectStl_sweep import *
import Polyline
def intersectStl_brutal(stlModel,layerThickness):
    layers=[]
    xMin,xMax,yMin,yMax,zMin,zMax=stlModel.getBounds()
    z=zMin +layerThickness
    while z<zMax:
        layer=Layer(z)
        for tri in stlModel.triangles:
            seg=intersectTriangleZPlane(tri,z)
            if seg is not  None:
                layer.segments.append(seg)
        layers.append(layer)
        z+=layerThickness
    return layers
def linkSegs_brutal(segs):
    segs=list(segs)
    contours=[]
    while len(segs)>0:
        contour=Polyline.Polyline()
        contours.append(contour)
        while len(segs)>0:
            for seg in segs:
                if contour.appendSegment(seg):
                    segs.remove(seg)
                    break
            if contour.isClosed():
                break
    return contours
def intersectStl_sweep(stlModel,layerThickness):
    return IntersectStl_sweep(stlModel,layerThickness).layers
def linkSegs_dorder(segs):
    return LinkSeg_dorder(segs).contours
def adjustPolygonDirs(polygons):    #调整多边形方向的函数，输入为轮廓列表
    for i in range(len(polygons)):      #第一个循环，取出多边形的起点
        pt=polygons[i].startPoint()
        insideCount=0
        for j in range(len(polygons)):    #第二个循环
            if j==i:continue
            restPoly=polygons[j]
            if 1==pointInPolygon(pt,restPoly):
                insideCount+=1
        if insideCount%2==0:
            polygons[i].makeCCW()
        else:
            polygons[i].makeCW()
def writeSlcFile(layers,path):
    f=None
    try:
        f=open(path,'w+b')   #打开或创建一个二进制文件
        f.write(bytes("-SLCVER 2.0 -UNIT MM",encoding='utf-8'))
        f.write(bytes([0x0d,0x0a,0x1a]))
        f.write(bytes([0x00]*256))
        f.write(struct.pack('b',1))
        f.write(struct.pack('4f',0,0,0,0))
        for layer in layers:
            f.write(struct.pack('fI',layer.z,len(layer.contours)))
            for contour in layer.contours:
                f.write(struct.pack('2I',contour.count(),0))
                for pt in contour.points:
                    f.write(struct.pack('2f',pt.x,pt.y))
        f.write(struct.pack('fI',layers[-1].z,0xFFFFFFFF))
    except Exception as ex:
        print("writeSlcFile exception:",ex)
    finally:
        if f:f.close()
        return layers


