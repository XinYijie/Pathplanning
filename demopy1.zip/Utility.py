

def makeListLinear(lists):
    outList=[]
    _makeListLinear(lists,outList)
    return outList
def _makeListLinear(inList,outList):
    for a in inList:
        if type(a)!=list:
            outList.append(a)
        else:
            _makeListLinear(a,outList)