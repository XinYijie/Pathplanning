import GemoBase
from Segment import *
class TVertex:          #定义Tvertex类，顶点拓扑类
    def __init__(self,pnt3d,digits=7):
        self.x=round(pnt3d.x,digits)
        self.y=round(pnt3d.y,digits)
        self.z=round(pnt3d.z,digits)
        self.faces=[]     #和顶点相接触的面片的引用
    def toTuple(self):     #将顶点转化为元组
        return (self.x,self.y,self.z)
    def toPoint3D(self):
        return GemoBase.Point3D(self.x,self.y,self.z)
    def isSmaller(self,other):     #比较两个顶点的大小
        if self.x<other.x:
            return True
        elif self.x ==other.x and self.y<other.y:
            return True
        elif self.x==other.x and self.y==other.y and self.z<other.z:
            return True
        return False

class TEdge:     #定义棱边拓扑类
    def __init__(self,tA,tB):
        self.A,self.B=tA,tB
        self.F=None    #所从属的面片引用
        self.OE=None    #对边引用
    def toTuple(self):   #将边转化为元组
        if self.A.isSmaller(self.B):
            return (self.A.x,self.A.y,self.A.z,self.B.x,self.B.y,self.B.z)
        else:
            return (self.B.x,self.B.y,self.B.z,self.A.x,self.A.y,self.A.z)
    def intersect(self,z):
        if min(self.A.z,self.B.z)>z or max(self.A.z,self.B.z)<z:
            return None
        elif self.A.z==self.B.z==z:
            return None
        else:
            if z==self.A.z:
                self.A.toPoint3D()
            else:
                ratio=(z-self.A.z)/(self.B.z-self.A.z)
                vec=self.A.toPoint3D().pointTo(self.B.toPoint3D()).amplified(ratio)
                pnt=self.A.toPoint3D()+vec
                return pnt


class TFace:                       #定义TFace类
    def __init__(self,tA,tB,tC,te1,te2,te3):      #关联3个顶点，三条线段
        self.A,self.B,self.C=tA,tB,tC
        self.E1,self.E2,self.E3=te1,te2,te3
        self.used=False           #面片是否被使用过

    def zMin(self):
        return min(self.A.z,self.B.z,self.C.z)
    def zMax(self):
        return max(self.A.z,self.B.z,self.C.z)
    def intersect(self,z):   #面片和z平面截交
        if self.zMin()>z or self.zMax()<z:
            return None,None,None
        elif self.A.z==self.B.z==self.C.z==z:
            return  None,None,None
        else:     #求截交
            c1=self.E1.intersect(z)
            c2=self.E2.intersect(z)
            c3=self.E3.intersect(z)
            if c1 is None:
                if c2 is not None and c3 is not None:
                    if c2.distance(c3)!=0.0:
                        return Segment(c2,c3),[self.E2,self.E3],None
            elif c2 is None:
                if c1 is not None and c3 is not None:
                    if c1.distance(c3)!=0.0:
                        return Segment(c1,c3),[self.E1,self.E3],None
            elif c3 is None:
                if c2 is not None and c1 is not None:
                    if c2.distance(c1)!=0.0:
                        return Segment(c1,c2),[self.E,self.E2],None
            elif c1 is not None and c2 is not None and c3 is not None:
                if c1.isIdentical(c2):
                    return Segment(c1,c3),[self.E3],self.B
                elif c2.isIdentical(c3):
                    return Segment(c1,c2)[self.E1],self.C
                elif c3.isIdentical(c1):
                    return Segment(c2,c3),[self.E2],self.A
            return None,None,None





